"""Read-only offline package check. Never enters a simulator session."""
from pathlib import Path
import sys,ast,json,hashlib,importlib.util,math
ROOT=Path(__file__).resolve().parent
attempts=[]
def deny_runtime(event,args):
    if event in {'socket.connect','socket.connect_ex','socket.bind','socket.getaddrinfo','subprocess.Popen','os.system'}:
        attempts.append(event)
        raise RuntimeError('Offline package check forbids networking and process launch: '+event)
sys.addaudithook(deny_runtime)
sys.dont_write_bytecode=True
sys.path[:0]=[str(ROOT/'code/Q1/python'),str(ROOT/'code/Q2/python'),str(ROOT/'code/Q3/python'),str(ROOT/'code/Q4/python'),str(ROOT/'code/shared')]
import q1_geometry as q1
import select_second_detection_point as q2
import run_q3_final_practice as q3
import run_q3_final_formal_session
assert q3.validate_final_evidence()['version']=='q3_final_strict84_v1_20260912'
f=ROOT/'code/Q4/python/q4_free_formal_v1/run_session.py'
spec=importlib.util.spec_from_file_location('q4_package_formal_entry',f)
q4=importlib.util.module_from_spec(spec);spec.loader.exec_module(q4)
assert q4.validate()['status']=='FINAL_USER_SELECTED'
assert q4.selected.VERSION=='q4_free_tasks_v1'
normal=q1.solve(q1.bearing_halfplanes([(-500,0,0),(0,-500,90)]))
assert abs(normal['diameter_interval_m'][0]-24.69271291186713)<1e-9
poly=q2.initial_outer_polygon((0,0),0,circle_sides=360)
cert=q2.correlated_reception_certificate((400,400),poly,(0,0))
assert cert['feasible']
assert hashlib.sha256((ROOT/'code/Q2/python/select_second_detection_point.py').read_bytes()).hexdigest()=='0ac20f18a63ed278377656bad635715b1789a5a39a32c540e46cfc9f8fd6eaa0'
py=list(ROOT.rglob('*.py'))
for p in py:ast.parse(p.read_text(encoding='utf-8-sig'),filename=str(p))
manifest=ROOT/'SHA256.json'
manifest_root=ROOT
if not manifest.exists():
    manifest=ROOT.parent/'SHA256.json'
    manifest_root=ROOT.parent
checked=0
if manifest.exists():
    manifest_data=json.loads(manifest.read_text(encoding='utf-8'))
    actual_files={
        p.relative_to(manifest_root).as_posix()
        for p in manifest_root.rglob('*')
        if p.is_file() and p.name not in {'SHA256.json','.DS_Store'}
        and '__pycache__' not in p.parts
    }
    listed_files=set(manifest_data)
    assert actual_files==listed_files,{
        'manifest_missing':sorted(actual_files-listed_files),
        'manifest_extra':sorted(listed_files-actual_files),
    }
    for relative,digest in manifest_data.items():
        path=manifest_root/relative
        assert hashlib.sha256(path.read_bytes()).hexdigest()==digest,relative
        checked+=1
assert not attempts,attempts
print(json.dumps({'status':'PASS','python_files_syntax_checked':len(py),'q1_example_diameter_m':normal['diameter_interval_m'][0],'q2_reception_certificate':True,'q2_retention_repair_preserved':True,'q3_frozen_entry_and_evidence':'PASS','q4_FREE_entry_and_evidence':'PASS','manifest_exact_file_set':True,'manifest_files_checked':checked,'network_or_process_attempts':attempts},ensure_ascii=False,indent=2))
