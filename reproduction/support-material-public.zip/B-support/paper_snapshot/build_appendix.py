"""Generate the appendix inventory and syntax-highlighted Python listings."""
from pathlib import Path
import ast
import csv
import hashlib
import json

from pygments import highlight
from pygments.formatters import LatexFormatter
from pygments.lexers import PythonLexer
from pygments.style import Style
from pygments.token import Comment, Keyword, Name, Number, Operator, String, Text

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


class ListingStyle(Style):
    styles = {
        Text: "#000000",
        Keyword: "#0000FF",
        Name.Builtin: "#008A99",
        Name.Function: "#000000",
        Name.Class: "#000000",
        Number: "#000000",
        Operator: "#000000",
        String: "#008000",
        Comment: "#6A737D",
    }


GROUPS=[
 ('final_code/','四问运行入口与入口检查'),
 ('code/Q1/','第一问几何模型'),('code/Q2/','第二问选点模型与相关分析'),
 ('code/Q3/','第三问模型及保留的开发程序'),('code/Q4/','第四问模型及保留的开发程序'),
 ('code/shared/','共享模型、统计制图与辅助工具'),
 ('results/Q3/practice/','第三问演练逐场记录及汇总'),('results/Q3/formal/','第三问正式公开记录'),
 ('results/Q3/experiments/','第三问离线比较结果'),
 ('results/Q4/practice/','第四问演练逐场记录及汇总'),('results/Q4/formal/','第四问正式公开记录'),
 ('results/Q4/experiments/','第四问离线比较结果'),('results/Q2/','第二问算例与验证结果'),
 ('results/','其余几何证据与历史研究结果'),
 ('formal_logs/','六份原名正式加密导出日志'),('evidence/','结果索引、来源对应与核对记录'),
 ('planning/','原包模型选择与依赖登记'),('examples/','入口示例输入'),
 ('paper_snapshot/','全文LaTeX、图表与附录生成文件'),
 ('portable_tools/','保留的辅助工具'),('archive/','历史材料用途索引')]

def classify(path):
    if '/' not in path:return '根目录','复现说明、依赖、校验入口与逐文件清单'
    for prefix,desc in GROUPS:
        if path.startswith(prefix):return prefix,desc
    raise ValueError('Unclassified submission path: '+path)


def main():
    selection = json.loads((HERE / 'appendix_selection.json').read_text(encoding='utf-8'))
    selected = selection['extensions']['files']
    assert len(selected) == len(set(selected))

    # Each source file is printed once; shared dependencies have their own group.
    groups = [
        ('B.1 第一问：几何区域与直径', ['final_code/q1_entry.py', 'code/Q1/python/q1_geometry.py']),
        ('B.2 第二问：保证接收选点', ['final_code/q2_entry.py', 'code/Q2/python/select_second_detection_point.py', 'code/Q2/python/q2_rolling.py']),
        ('B.3 第三问：有限费用前瞻', ['final_code/q3_entry.py', 'code/Q3/python/q3_final_main.py', 'code/shared/search_policy_q3_cost_rollout_strict84_selected.py', 'code/shared/search_policy_q3_cost_rollout_v2.py', 'code/shared/q3_cost_rollout_v2.py', 'code/shared/search_policy_q3_combined.py']),
        ('B.4 第四问：覆盖搜索与冗余扫描删除', ['final_code/q4_entry.py'] + [p for p in selected if p.startswith('code/Q4/') or p.startswith('code/shared/search_policy_q4_') or p == 'code/shared/q4_joint_compatibility.py']),
        ('B.5 共享几何、定位与路线模块', []),
        ('B.6 演练统计与制图', ['code/shared/statistics_helpers.py', 'code/shared/generate_practice_assets.py']),
    ]
    assigned = {p for _, paths in groups for p in paths}
    groups[4][1].extend(p for p in selected if p not in assigned)
    ordered = [p for _, paths in groups for p in paths]
    assert len(ordered) == len(selected) and set(ordered) == set(selected)

    formatter = LatexFormatter(style=ListingStyle, commandprefix='PY')
    lexer = PythonLexer(stripnl=False, ensurenl=False)
    tex = [r"""\section*{附录A：支撑材料文件清单}
支撑材料按原目录组织。下表按目录归并列出全部文件；\texttt{文件清单.csv}给出完整逐文件路径，\texttt{文件角色说明.json}说明其用途。
\input{appendix_directory_table.tex}
四问入口为\texttt{final\_code/}中的\texttt{q1\_entry.py}至\texttt{q4\_entry.py}。模型源码、实验结果、六份正式日志与全文LaTeX均在对应目录中，运行方法见根目录复现说明。

\clearpage
\section*{附录B：模型与统计制图代码清单}
以下按四问模型、共享模块和统计制图列出完整程序，共用模块仅列一次。每份文件从第1行编号，保留原始源码的空行、注释和缩进；长行仅在版面中折行，续行不另编号。运行时使用支撑材料中的原始源码文件。
\begingroup
\linespread{1}\selectfont
\definecolor{ListingBackground}{RGB}{248,248,248}
\definecolor{ListingBorder}{RGB}{211,211,211}
\renewcommand{\theFancyVerbLine}{\sffamily\fontsize{7.5}{9}\selectfont\arabic{FancyVerbLine}}
\fvset{breaklines=true,breakanywhere=true,fontsize=\fontsize{8.5}{10.3}\selectfont,baselinestretch=1,numbers=left,numbersep=7pt,firstnumber=1,stepnumber=1,numberblanklines=true,xleftmargin=20pt,xrightmargin=0pt,frame=single,framerule=0.45pt,rulecolor=\color{ListingBorder},backgroundcolor=ListingBackground,backgroundcolorpadding=3pt,breaksymbolleft=\textcolor{gray}{\tiny\ensuremath{\hookrightarrow}},tabsize=4}
""", formatter.get_style_defs()]
    records = []
    listing_number = 0
    for title, paths in groups:
        tex.append(r'\Needspace{7\baselineskip}' + '\n' + r'\subsection*{' + title + '}')
        for relative in paths:
            source = ROOT / relative
            text = source.read_text(encoding='utf-8-sig')
            tokens = list(lexer.get_tokens(text))
            assert ''.join(value for _, value in tokens) == text, relative
            ast.parse(text, filename=relative)
            listing_number += 1
            tex.append(r'\Needspace{6\baselineskip}' + '\n' + r'\noindent{\footnotesize 代码清单 B.' + str(listing_number) + r'\quad\nolinkurl{' + relative + r'}}\par\smallskip')
            highlighted = highlight(text, lexer, formatter)
            begin_line = sum(part.count('\n') + 1 for part in tex) + 1
            tex.append(highlighted)
            records.append({
                'source': relative,
                'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                'source_lines': len(text.splitlines()),
                'listing_number': listing_number,
                'printed': 'appendix_submission.tex',
                'tex_begin_line': begin_line,
                'tex_end_line': begin_line + highlighted.count('\n'),
                'source_preserved_by_tokenization': True,
            })
    tex.append(r'\endgroup')
    (HERE / 'appendix_submission.tex').write_text('\n'.join(tex) + '\n', encoding='utf-8')
    (HERE / 'appendix_listing_map.json').write_text(json.dumps({
        'schema_version': 2,
        'artifact_type': 'appendix-listing-map',
        'extensions': {
            'transformation': 'Syntax highlighting only; preserve every source line, comment and statement. Line numbers match each original file.',
            'files': records,
        },
    }, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    # Generated filenames must exist before the package inventory is counted.
    inventory = HERE / 'appendix_directory_table.tex'
    if not inventory.exists():
        inventory.write_text('', encoding='utf-8')
    files = sorted(p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()
                   and '__pycache__' not in p.parts and p.name != '.DS_Store')
    by_group = {}
    descriptions = {}
    for relative in files:
        group, description = classify(relative)
        by_group.setdefault(group, []).append(relative)
        descriptions[group] = description
    order = ['根目录'] + [prefix for prefix, _ in GROUPS]
    table = [r'\begingroup\footnotesize\renewcommand{\arraystretch}{1.08}',
             r'\begin{longtable}{@{}p{.37\textwidth}rp{.51\textwidth}@{}}',
             r'\caption{支撑材料文件清单（按目录归并）}\\',
             r'\toprule 目录 & 文件数 & 主要内容\\\midrule\endhead']
    for group in order:
        if group not in by_group:
            continue
        label = '根目录下的文件' if group == '根目录' else r'\path{' + group + '}'
        if group == 'results/':
            label = r'\path{results/}其余子目录'
        table.append(f'{label} & {len(by_group[group])} & {descriptions[group]}' + r'\\')
    table += [rf'\midrule 合计 & {len(files)} & 完整逐文件路径见文件清单CSV\\',
              r'\bottomrule\end{longtable}\endgroup']
    inventory.write_text('\n'.join(table) + '\n', encoding='utf-8')
    with (ROOT / '文件清单.csv').open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(['relative_path', 'group', 'role'])
        writer.writerows([relative, *classify(relative)] for relative in files)
    (HERE / 'file_list_compact.txt').write_text('\n'.join(
        f'{group}: {len(by_group[group])} files; {descriptions[group]}'
        for group in order if group in by_group) + '\n', encoding='utf-8')
    print(json.dumps({'modules': len(records), 'source_lines': sum(r['source_lines'] for r in records),
                      'source_tokenization_exact': True, 'files': len(files)}))


if __name__ == '__main__':
    main()
