$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    & xelatex -interaction=nonstopmode -halt-on-error B_q12_focus_20260913.tex
    if ($LASTEXITCODE -ne 0) { throw 'First XeLaTeX pass failed' }
    & bibtex B_q12_focus_20260913
    if ($LASTEXITCODE -ne 0) { throw 'BibTeX failed' }
    & xelatex -interaction=nonstopmode -halt-on-error B_q12_focus_20260913.tex
    if ($LASTEXITCODE -ne 0) { throw 'Second XeLaTeX pass failed' }
    & xelatex -interaction=nonstopmode -halt-on-error B_q12_focus_20260913.tex
    if ($LASTEXITCODE -ne 0) { throw 'Final XeLaTeX pass failed' }
} finally {
    Pop-Location
}
