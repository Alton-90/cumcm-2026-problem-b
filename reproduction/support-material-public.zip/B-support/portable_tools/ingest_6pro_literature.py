"""可移植入口：从显式目录导入历史六份参考材料。"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FILES = [
    ("MD", "B题_文献研读成果_交总控.md"),
    ("P1", "无人机无线电监测混合定位算法.pdf"),
    ("P2", "tokekar2013asensor.pdf"),
    ("P3", "RSS-Based_Localization_of_Multiple_Directional_Sources_With_Unknown_Transmit_Powers_and_Orientations.pdf"),
    ("P4a", "Journal of Field Robotics - 2014 - Vander Hook - Cautious Greedy Strategy for Bearing‐only Active Localization  Analysis.pdf"),
    ("P4b", "JoshV_JFR_2013_Localization.pdf"),
    ("P5", "IEEE_TRO_2012.pdf"),
]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", required=True)
    parser.add_argument(
        "--output-dir",
        default=str(ROOT / "planning" / "literature" / "6pro_20260911"),
    )
    args = parser.parse_args()
    try:
        import fitz
    except ImportError as exc:
        raise RuntimeError("请安装requirements-analysis.txt") from exc

    source_dir = Path(args.source_dir).expanduser().resolve()
    output_dir = Path(args.output_dir).expanduser().resolve()
    if not source_dir.is_dir():
        raise FileNotFoundError(f"文献源目录不存在: {source_dir}")
    output_dir.mkdir(parents=True, exist_ok=True)
    records = []
    for ident, name in FILES:
        source = source_dir / name
        if not source.is_file():
            raise FileNotFoundError(f"缺少文献源文件: {source}")
        target = output_dir / name
        sha = digest(source)
        if target.exists() and digest(target) != sha:
            raise ValueError(f"已有目标与源文件不一致: {target}")
        if not target.exists():
            shutil.copyfile(source, target)
        item = {"id": ident, "name": name, "sha256": sha}
        if name.lower().endswith(".pdf"):
            document = fitz.open(target)
            item["pages"] = len(document)
            text = "\n\n".join(
                f"===== PDF PAGE {i + 1} =====\n" + page.get_text(sort=True)
                for i, page in enumerate(document)
            )
            (output_dir / f"{ident}_extracted.txt").write_text(text, encoding="utf-8")
        records.append(item)
    (output_dir / "source_manifest.json").write_text(
        json.dumps(records, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(records, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
