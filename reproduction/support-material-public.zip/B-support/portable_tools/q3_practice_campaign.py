"""可移植入口：为冻结的Q3演练脚本自动发现PowerShell 7。"""

from __future__ import annotations

import importlib.util
import os
import shutil
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "code" / "shared" / "q3_practice_campaign.py"


def main() -> int:
    pwsh = os.environ.get("PWSH") or shutil.which("pwsh")
    if "run" in sys.argv[1:] and not pwsh:
        raise RuntimeError("未找到PowerShell 7；请将pwsh加入PATH或设置PWSH环境变量")
    if not hasattr(subprocess, "CREATE_NO_WINDOW"):
        subprocess.CREATE_NO_WINDOW = 0
    spec = importlib.util.spec_from_file_location("frozen_q3_practice_campaign", SOURCE)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    if pwsh:
        module.PWSH = pwsh
    module.main()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
