"""可移植入口：显式接收工作区和Schema路径后校验历史文献绑定。"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


DEFAULT_ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require_file(path: Path, description: str) -> Path:
    if not path.is_file():
        raise FileNotFoundError(f"缺少{description}: {path}")
    return path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=str(DEFAULT_ROOT), help="完整研究工作区")
    parser.add_argument("--schema", required=True, help="report-binding.schema.json")
    parser.add_argument("--output", help="校验结果输出路径")
    args = parser.parse_args()

    try:
        import jsonschema
    except ImportError as exc:
        raise RuntimeError("请安装requirements-analysis.txt") from exc

    root = Path(args.root).expanduser().resolve()
    schema_path = require_file(Path(args.schema).expanduser().resolve(), "Schema")
    binding_path = require_file(
        root / "planning" / "literature" / "related_paper_analysis.json",
        "文献报告绑定",
    )
    binding = json.loads(binding_path.read_text(encoding="utf-8"))
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    jsonschema.Draft202012Validator(schema).validate(binding)

    references = [binding["report"], *binding["inputs"]]
    errors = []
    for record in references:
        path = root / record["path"]
        if not path.is_file() or sha256(path) != record["sha256"]:
            errors.append(record["path"])
    if errors:
        raise ValueError(f"依赖缺失或哈希失效: {errors}")

    result = {
        "status": "PASS",
        "schema_path": str(schema_path),
        "binding_sha256": sha256(binding_path),
        "checked_direct_references": len(references),
        "method_approved": False,
        "limitation": "本工具只验证Schema和直接依赖哈希，不授予建模门控状态。",
    }
    if args.output:
        output = Path(args.output).expanduser().resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
