"""可移植入口：运行冻结的几何探针，但将输出定位到当前提交包。"""

from __future__ import annotations

import argparse
import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "code" / "shared" / "verify_geometry_probes.py"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output",
        default=str(ROOT / "results" / "diagnostics" / "geometry_probes.json"),
    )
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location("frozen_geometry_probes", SOURCE)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    module.ROOT = ROOT
    module.OUT = Path(args.output).expanduser().resolve()
    module.main()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
