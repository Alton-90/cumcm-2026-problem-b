"""一键执行环境、核心算例、单元测试、论文数字与文件完整性检查。"""

from __future__ import annotations

import json
import os
import platform
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PYTHON_DIRS = [
    ROOT / "code" / "shared",
    ROOT / "code" / "Q1" / "python",
    ROOT / "code" / "Q2" / "python",
    ROOT / "code" / "Q3" / "python",
    ROOT / "code" / "Q4" / "python",
]


def run_step(name: str, command: list[str], env: dict[str, str]) -> dict:
    print(f"\n[{name}] {' '.join(command)}", flush=True)
    completed = subprocess.run(
        command,
        cwd=ROOT,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if completed.stdout:
        print(completed.stdout.rstrip(), flush=True)
    if completed.returncode != 0:
        raise RuntimeError(f"{name}失败，退出码{completed.returncode}")
    return {"name": name, "status": "PASS"}


def main() -> int:
    version = sys.version_info
    if version < (3, 12):
        raise RuntimeError(f"需要Python 3.12或更高版本，当前为{platform.python_version()}")

    try:
        import numpy
    except ImportError as exc:
        raise RuntimeError(
            "缺少NumPy，请先执行：python -m pip install -r requirements.txt"
        ) from exc

    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONUTF8"] = "1"
    previous = env.get("PYTHONPATH")
    paths = [str(path) for path in PYTHON_DIRS]
    if previous:
        paths.append(previous)
    env["PYTHONPATH"] = os.pathsep.join(paths)

    steps = [
        {
            "name": "environment",
            "status": "PASS",
            "python": platform.python_version(),
            "implementation": platform.python_implementation(),
            "numpy": numpy.__version__,
            "workspace": str(ROOT),
            "validated_range": "Python 3.12-3.13",
            "range_warning": version[:2] not in {(3, 12), (3, 13)},
        }
    ]
    commands = [
        (
            "四问最终入口",
            [sys.executable, "-B", "-X", "utf8", str(ROOT / "final_code" / "check_entries.py")],
        ),
        (
            "核心算例与文件完整性",
            [sys.executable, "-B", "-X", "utf8", str(ROOT / "check_package.py")],
        ),
        (
            "完整单元测试",
            [sys.executable, "-B", "-X", "utf8", str(ROOT / "run_unit_tests.py")],
        ),
        (
            "已有模拟器材料逐场核对",
            [sys.executable, "-B", "-X", "utf8", str(ROOT / "code" / "shared" / "verify_simulator_materials.py")],
        ),
        (
            "论文关键数字复算",
            [sys.executable, "-B", "-X", "utf8", str(ROOT / "verify_paper_numbers.py")],
        ),
    ]

    try:
        for name, command in commands:
            steps.append(run_step(name, command, env))
    except Exception as exc:
        print(
            json.dumps(
                {"status": "FAIL", "error": str(exc), "steps": steps},
                ensure_ascii=False,
                indent=2,
            )
        )
        return 1

    print(
        json.dumps(
            {"status": "PASS", "steps": steps},
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
