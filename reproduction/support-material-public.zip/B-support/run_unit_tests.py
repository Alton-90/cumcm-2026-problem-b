"""运行全部单元测试，并为未随提交包交付的Q2探索结果提供受控夹具。"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
FIXTURE_PATH = (
    ROOT
    / "results"
    / "paper_q12_geometry_v2"
    / "q2_correlated_reception_domain_diagnostic.json"
)


def fixture_data() -> dict:
    return {
        "_test_fixture_only": True,
        "status": "EXPLORATORY_NOT_APPROVED_METHOD_OR_BASELINE",
        "preserved_initial_screen": {"screening_result": {"status": "FAIL"}},
        "screening_result": {"status": "PASS"},
        "finest_selected_candidates": {
            "first_reception_correlated": {
                "fixture": {"correlated_slack_m": 0.1}
            }
        },
    }


def main() -> int:
    created_fixture = False
    created_directory = False
    if not FIXTURE_PATH.exists():
        if not FIXTURE_PATH.parent.exists():
            FIXTURE_PATH.parent.mkdir(parents=True)
            created_directory = True
        FIXTURE_PATH.write_text(
            json.dumps(fixture_data(), ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        created_fixture = True

    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONUTF8"] = "1"
    python_dirs = [
        ROOT / "code" / "shared",
        ROOT / "code" / "Q1" / "python",
        ROOT / "code" / "Q2" / "python",
        ROOT / "code" / "Q3" / "python",
        ROOT / "code" / "Q4" / "python",
    ]
    env["PYTHONPATH"] = os.pathsep.join(
        [str(path) for path in python_dirs]
        + ([env["PYTHONPATH"]] if env.get("PYTHONPATH") else [])
    )

    try:
        completed = subprocess.run(
            [
                sys.executable,
                "-B",
                "-X",
                "utf8",
                "-m",
                "unittest",
                "discover",
                "-s",
                str(ROOT / "code" / "shared"),
                "-p",
                "test_*.py",
                "-v",
            ],
            cwd=ROOT,
            env=env,
            check=False,
        )
        return completed.returncode
    finally:
        if created_fixture:
            FIXTURE_PATH.unlink(missing_ok=True)
        if created_directory:
            try:
                FIXTURE_PATH.parent.rmdir()
            except OSError:
                pass


if __name__ == "__main__":
    raise SystemExit(main())
