"""从逐场证据重新计算论文关键数字，并核对LaTeX正文。"""

from __future__ import annotations

import json
import math
import statistics
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PACKAGE_ROOT = ROOT.parent
EVIDENCE_PATH = ROOT / "evidence" / "verified_results.json"
sys.path.insert(0,str(ROOT/'code/shared'))
from generate_practice_assets import build_tables


def locate_paper_source() -> Path:
    """优先核对工作包正文；ZIP独立运行时核对随包冻结的论文快照。"""
    snapshot = ROOT / "paper_snapshot"
    if snapshot.is_dir():
        return snapshot
    raise FileNotFoundError("未找到论文LaTeX正文或paper_snapshot冻结快照")


def require_close(name: str, actual: float, expected: float, tol: float = 1e-9) -> dict:
    if not math.isclose(actual, expected, rel_tol=tol, abs_tol=tol):
        raise AssertionError(f"{name}: 复算值{actual}与登记值{expected}不一致")
    return {"name": name, "value": actual, "status": "PASS"}


def main() -> int:
    evidence = json.loads(EVIDENCE_PATH.read_text(encoding="utf-8"))
    checks = []

    for question in ("Q3", "Q4"):
        rows = evidence["practice"][question]
        summary = evidence["summary"][question]
        values = [float(row["value"]) for row in rows]
        sources = sum(int(row["N"]) for row in rows)
        cleared = sum(int(row["cleared"]) for row in rows)
        total_time = sum(float(row["total"]) for row in rows)
        if any(int(row["N"]) != int(row["cleared"]) for row in rows):
            raise AssertionError(f"{question}: 存在未完整清除的演练记录")
        if len({row["case_id"] for row in rows}) != len(rows):
            raise AssertionError(f"{question}: 演练案例编码重复")

        checks.extend(
            [
                require_close(f"{question}_practice_n", len(rows), summary["n"]),
                require_close(
                    f"{question}_practice_mean",
                    statistics.mean(values),
                    summary["mean"],
                ),
                require_close(
                    f"{question}_practice_sd",
                    statistics.stdev(values),
                    summary["sd"],
                ),
                require_close(f"{question}_sources", sources, summary["sources"]),
                require_close(f"{question}_cleared", cleared, summary["cleared"]),
                require_close(
                    f"{question}_pooled_mean",
                    total_time / sources,
                    summary["pooled"],
                ),
            ]
        )

        formal_rows = [
            row for row in evidence["formal"] if row["question"] == question
        ]
        formal_summary = summary["formal"]
        checks.extend(
            [
                require_close(
                    f"{question}_formal_n", len(formal_rows), formal_summary["n"]
                ),
                require_close(
                    f"{question}_formal_cleared",
                    sum(int(row["cleared"]) for row in formal_rows),
                    formal_summary["cleared"],
                ),
                require_close(
                    f"{question}_formal_mean",
                    statistics.mean(float(row["value"]) for row in formal_rows),
                    formal_summary["mean"],
                ),
            ]
        )

    q3_comparison = json.loads(
        (
            ROOT
            / "results"
            / "Q3"
            / "experiments"
            / "final_integration_20260912"
            / "metrics"
            / "comparison.json"
        ).read_text(encoding="utf-8")
    )
    checks.append(
        require_close(
            "Q3_validation_improvement",
            q3_comparison["datasets"]["validation"]["reduction"],
            0.012904162467912927,
        )
    )

    q4_comparison = json.loads(
        (
            ROOT
            / "results"
            / "Q4"
            / "experiments"
            / "free_tasks_v1"
            / "validation"
            / "summary.json"
        ).read_text(encoding="utf-8")
    )
    checks.append(
        require_close(
            "Q4_validation_improvement",
            q4_comparison["gain"],
            0.02047335278181328,
        )
    )

    paper_source = locate_paper_source()
    latex_files = [
        paper_source / "B_q12_focus_20260913.tex",
        paper_source / "results.tex",
    ]
    latex = "\n".join(path.read_text(encoding="utf-8") for path in latex_files)
    generated=build_tables(evidence)
    for name,expected in generated.items():
        assert (paper_source/name).read_text(encoding='utf-8')==expected,name
    macros=dict(re.findall(r'\\newcommand\{\\(\w+)\}\{([^{}]*)\}',generated['auto_practice_numbers.tex']))
    for name,value in macros.items():latex=re.sub(r'\\'+name+r'\b\s*',lambda m:value,latex)
    q3=evidence['summary']['Q3'];q4=evidence['summary']['Q4']
    required_fragments = (
        f"{q3['n']}场演练清除{q3['cleared']}/{q3['sources']}个源",
        f"{q3['mean']:.2f}秒/源",
        f"{q4['n']}场演练清除{q4['cleared']}/{q4['sources']}个源",
        f"{q4['mean']:.2f}秒/源",
        "266.46和484.60秒/源",
        "1.2904\\%",
        "2.0473\\%",
    )
    missing = [fragment for fragment in required_fragments if fragment not in latex]
    if missing:
        raise AssertionError(f"LaTeX正文缺少关键数字片段: {missing}")
    assert not any(s in latex for s in ['115场演练','1489/1489','505.37秒/源','118次','421场','AI工具使用声明'])
    checks.append({'name':'generated_tables_and_macros_match_case_records','files':list(generated),'status':'PASS'})
    checks.append(
        {"name": "latex_key_numbers_present", "count": len(required_fragments), "status": "PASS"}
    )

    print(
        json.dumps(
            {
                "status": "PASS",
                "evidence": str(EVIDENCE_PATH.relative_to(ROOT)),
                "paper_source": str(paper_source.relative_to(ROOT))
                if paper_source.is_relative_to(ROOT)
                else str(paper_source),
                "checks": checks,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
